Thanks for downloading *Voltaire Browser*, the latest fully functional unblocked browser!


== HOW TO INSTALL ==
Here are the steps to actually install it on chrome (you can't just open the html file, it doesn't work):
https://docs.google.com/document/d/1JQmokOOMqgV5BFe61xBBSkH7UI06-6SHG1IeSalpvKo/edit

You have already downloaded this, so ignore step 1 on the doc


== JOIN THE DISCORD SERVER! ==
If you are having any issues or feedback, join the Discord server. I'm always happy to help!!
https://discord.gg/wahdQHBs4Z


== OPTIONAL FORM ==
Also, I really want to know how far Voltaire Browser is spreading, and I have no easy way to do that.
So, answering this form would help me:
https://forms.gle/8AoWLiYzGXu3BNMv8


Again, thank you, and enjoy using the browser
- Cadecraft (2022/7/2)


My site: https://cadecraft.github.io
YouTube: https://www.youtube.com/c/AwesomeCadecraft
Discord Server: https://discord.gg/wahdQHBs4Z
GitHub Repository: https://github.com/Cadecraft/voltaire-browser-source