# voltaire-browser
A fully functional unblocked browser app for Chromebooks by Cadecraft. Features: bookmarks, fast google search, quick links, tab management, and efficient loading.

In order to install, please check this doc: https://docs.google.com/document/d/1JQmokOOMqgV5BFe61xBBSkH7UI06-6SHG1IeSalpvKo/edit

See more info on my website, https://cadecraft.github.io/.

NOTE: This is the most recent version of the browser, so it is potentially unstable--if you are hoping to download and use it, please use the drive link (on my website) to the last stable version.